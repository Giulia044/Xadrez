package view;

import controller.Game;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.swing.*;
import javax.swing.border.MatteBorder;
import model.board.Position;
import model.pieces.Piece;

/**
 * Interface gráfica do jogo de xadrez.
 */
public class ChessGUI extends JFrame {

    // -------------------- Configuração visual --------------------
    private static final long serialVersionUID = 2L;
    /** Cor clara das casas (creme). */
    private static final Color COR_CLARA = new Color(255, 179, 204);

    private static final Color COR_ESCURA = new Color(153, 0, 51);
    /** Destaque da casa selecionada. */
    private static final Color COR_SELECIONADA = new Color(30, 144, 255, 180);
    /** Destaque das jogadas legais. */
    private static final Color COR_LEGAL = new Color(255, 255, 255, 160);
    /** Destaque do destino do último lance. */
    private static final Color COR_ULTIMO_LANCE = new Color(220, 50, 47, 180);

    // -------------------- Estado da UI --------------------
    private final Game jogo;
    private final TabuleiroPanel painelTabuleiro;
    private final JTextArea areaHistorico = new JTextArea(14, 24);

    /** Posição selecionada pelo usuário (origem). */
    private Position selecionada = null;
    /** Jogadas legais a partir da posição selecionada. */
    private List<Position> legaisDaSelecionada = new ArrayList<>();

    /** IA simples: computador joga com pretas? */
    private boolean computadorPretas = true;
    private final Random rnd = new Random();

    public ChessGUI() {
        super("Jogo de Xadrez com Computador");

        // Look&Feel moderno e ícone diferente para dar identidade única
        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception ignored) {}
        setIconImage(new ImageIcon("resources/bK.png").getImage());

        this.jogo = new Game();
        this.painelTabuleiro = new TabuleiroPanel();

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(8, 8));

        // Menu superior com opções básicas
        setJMenuBar(criarMenu());

        // Área lateral: histórico simples
        areaHistorico.setEditable(false);
        areaHistorico.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
        JScrollPane scroll = new JScrollPane(areaHistorico);
        scroll.setBorder(new MatteBorder(0, 1, 0, 0, new Color(0,0,0,40)));

        add(painelTabuleiro, BorderLayout.CENTER);
        add(scroll, BorderLayout.EAST);

        pack();
        setMinimumSize(new Dimension(720, 620));
        setLocationRelativeTo(null);
        atualizarHistorico();
    }

    // -------------------- Menu --------------------
    private JMenuBar criarMenu() {
        JMenuBar bar = new JMenuBar();

        JMenu jogoMenu = new JMenu("Jogo");
        JMenuItem novo = new JMenuItem("Novo Jogo");
        novo.addActionListener(e -> {
            jogo.newGame();
            selecionada = null;
            legaisDaSelecionada.clear();
            atualizarHistorico();
            painelTabuleiro.repaint();
        });

        JCheckBoxMenuItem pcPretasItem = new JCheckBoxMenuItem("Computador joga de pretas", computadorPretas);
        pcPretasItem.addActionListener(e -> computadorPretas = pcPretasItem.isSelected());

        jogoMenu.add(novo);
        jogoMenu.add(pcPretasItem);
        bar.add(jogoMenu);

        JMenu exibir = new JMenu("Exibir");
        JCheckBoxMenuItem bordasArred = new JCheckBoxMenuItem("Casas arredondadas", true);
        bordasArred.addActionListener(e -> {
            painelTabuleiro.casasArredondadas = bordasArred.isSelected();
            painelTabuleiro.repaint();
        });
        exibir.add(bordasArred);
        bar.add(exibir);

        return bar;
    }

    // -------------------- Interação/IA --------------------
    /** Faz a jogada automática do computador (muito simples): escolhe um lance aleatório. */
    private void jogadaDoComputador() {
        if (!computadorPretas) return;
        if (jogo.isGameOver()) return;
        if (jogo.whiteToMove()) return; // computador é preto

        List<Movimento> todos = gerarTodosLancesDoLadoAtual();
        if (todos.isEmpty()) return;

        Movimento m = todos.get(rnd.nextInt(todos.size()));
        jogo.move(m.de, m.para, null);
        atualizarHistorico();
        painelTabuleiro.repaint();
    }

    /** Gera todos os lances possíveis do lado a jogar, varrendo o tabuleiro. */
    private List<Movimento> gerarTodosLancesDoLadoAtual() {
        List<Movimento> lista = new ArrayList<>();
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                Position p = new Position(r, c);
                Piece pc = jogo.board().get(p);
                if (pc == null) continue;
                if (pc.isWhite() != jogo.whiteToMove()) continue;
                for (Position to : jogo.legalMovesFrom(p)) {
                    lista.add(new Movimento(p, to));
                }
            }
        }
        return lista;
    }

    /** Atualiza a área de histórico com a lista de lances do Game. */
    private void atualizarHistorico() {
        StringBuilder sb = new StringBuilder();
        List<String> hist = jogo.history();
        for (int i = 0; i < hist.size(); i++) {
            if (i % 2 == 0) sb.append((i/2 + 1)).append(". ");
            sb.append(hist.get(i)).append(' ');
            if (i % 2 == 1) sb.append('\n');
        }
        areaHistorico.setText(sb.toString());
        areaHistorico.setCaretPosition(areaHistorico.getDocument().getLength());
    }

    // -------------------- Painel do Tabuleiro --------------------
    private class TabuleiroPanel extends JPanel {
        boolean casasArredondadas = true;
        int margem = 20;

        TabuleiroPanel() {
            setPreferredSize(new Dimension(560, 560));
            setBackground(new Color(20, 20, 20));

            addMouseListener(new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e) {
                    int tamanhoCasa = (Math.min(getWidth(), getHeight()) - 2 * margem) / 8;
                    int offsetX = (getWidth() - 8 * tamanhoCasa) / 2;
                    int offsetY = (getHeight() - 8 * tamanhoCasa) / 2;
                    int col = (e.getX() - offsetX) / tamanhoCasa;
                    int row = (e.getY() - offsetY) / tamanhoCasa;
                    if (col < 0 || col >= 8 || row < 0 || row >= 8) return;

                    Position clicada = new Position(row, col);
                    Piece p = jogo.board().get(clicada);

                    // Se clicou na mesma casa -> desmarca
                    if (selecionada != null && selecionada.equals(clicada)) {
                        selecionada = null;
                        legaisDaSelecionada.clear();
                        repaint();
                        return;
                    }

                    // Se já há origem selecionada e destino é legal -> efetiva jogada
                    if (selecionada != null) {
                        for (Position dest : legaisDaSelecionada) {
                            if (dest.equals(clicada)) {
                                // Promoção simples: promove para Dama automaticamente
                                if (jogo.isPromotion(selecionada, clicada)) {
                                    // No Game, a promoção geralmente é tratada na própria move() ou via escolha separada;
                                    // aqui apenas chamamos move().
                                }
                                jogo.move(selecionada, clicada, null);
                                selecionada = null;
                                legaisDaSelecionada.clear();
                                atualizarHistorico();
                                repaint();

                                // Depois do humano jogar, computador responde
                                SwingUtilities.invokeLater(() -> {
                                    jogadaDoComputador();
                                });
                                return;
                            }
                        }
                    }

                    // Se não moveu, selecionar nova origem se for peça do lado a jogar
                    if (p != null && p.isWhite() == jogo.whiteToMove()) {
                        selecionada = clicada;
                        legaisDaSelecionada = new ArrayList<>(jogo.legalMovesFrom(selecionada));
                    } else {
                        selecionada = null;
                        legaisDaSelecionada.clear();
                    }
                    repaint();
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g0) {
            super.paintComponent(g0);
            Graphics2D g = (Graphics2D) g0;
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int tamanhoCasa = (Math.min(getWidth(), getHeight()) - 2 * margem) / 8;
            int w = 8 * tamanhoCasa, h = 8 * tamanhoCasa;
            int offsetX = (getWidth() - w) / 2;
            int offsetY = (getHeight() - h) / 2;

            // Moldura externa
            g.setColor(new Color(0,0,0,60));
            g.fillRoundRect(offsetX - 8, offsetY - 8, w + 16, h + 16, 24, 24);

            // Desenha casas (com opção arredondada para variar bastante do original)
            for (int r = 0; r < 8; r++) {
                for (int c = 0; c < 8; c++) {
                    boolean escura = ((r + c) & 1) == 1;
                    g.setColor(escura ? COR_ESCURA : COR_CLARA);
                    int x = offsetX + c * tamanhoCasa;
                    int y = offsetY + r * tamanhoCasa;
                    if (casasArredondadas) {
                        g.fillRoundRect(x, y, tamanhoCasa, tamanhoCasa, 18, 18);
                    } else {
                        g.fillRect(x, y, tamanhoCasa, tamanhoCasa);
                    }
                }
            }

            // Destaques da seleção e movimentos legais
            if (selecionada != null) {
                int sx = offsetX + selecionada.getColumn() * tamanhoCasa;
                int sy = offsetY + selecionada.getRow() * tamanhoCasa;
                g.setColor(COR_SELECIONADA);
                g.fillRoundRect(sx+2, sy+2, tamanhoCasa-4, tamanhoCasa-4, 16, 16);

                g.setColor(COR_LEGAL);
                for (Position p : legaisDaSelecionada) {
                    int lx = offsetX + p.getColumn() * tamanhoCasa;
                    int ly = offsetY + p.getRow() * tamanhoCasa;
                    int d = Math.max(8, tamanhoCasa/5);
                    g.fillOval(lx + (tamanhoCasa - d)/2, ly + (tamanhoCasa - d)/2, d, d);
                }
            }

            // Destaque do destino do último movimento
            if (jogo.getLastMove() != null) {
                Position dest = jogo.getLastMove().getTo();
                int dx = offsetX + dest.getColumn() * tamanhoCasa;
                int dy = offsetY + dest.getRow() * tamanhoCasa;
                g.setColor(COR_ULTIMO_LANCE);
                g.setStroke(new BasicStroke(3f));
                g.drawRoundRect(dx+2, dy+2, tamanhoCasa-4, tamanhoCasa-4, 14, 14);
            }

            // Desenha as peças usando as imagens já existentes
           // ...existing code...
for (int r = 0; r < 8; r++) {
    for (int c = 0; c < 8; c++) {
        Piece p = jogo.board().get(new Position(r, c));
        if (p == null) continue;
        Image img = ImageUtil.getImageFor(p, tamanhoCasa - 8); // usa o tamanho da casa menos margem
        int x = offsetX + c * tamanhoCasa;
        int y = offsetY + r * tamanhoCasa;
        g.drawImage(img, x + 4, y + 4, tamanhoCasa - 8, tamanhoCasa - 8, null);
    }
}


            // Coordenadas laterais (a-h, 1-8) para um visual diferente do original
            g.setFont(getFont().deriveFont(Font.BOLD, 12f));
            g.setColor(new Color(255,255,255,200));
            for (int c = 0; c < 8; c++) {
                String file = String.valueOf((char)('a' + c));
                int x = offsetX + c * tamanhoCasa + tamanhoCasa - 14;
                int y = offsetY + h + 14;
                g.drawString(file, x, y);
            }
            for (int r = 0; r < 8; r++) {
                String rank = String.valueOf(8 - r);
                int x = offsetX - 14;
                int y = offsetY + r * tamanhoCasa + 14;
                g.drawString(rank, x, y);
            }
        }
    }

    /** Estrutura simples para representar um lance localmente na GUI. */
    private static class Movimento {
        final Position de, para;
        Movimento(Position de, Position para) { this.de = de; this.para = para; }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ChessGUI().setVisible(true));
    }
}
